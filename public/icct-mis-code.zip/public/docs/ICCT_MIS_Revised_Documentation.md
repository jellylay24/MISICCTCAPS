# FULLY REVISED DOCUMENTATION
## Based on the Deployed ICCT MIS Website
### https://icct-mis.classapparelph.com

---

## Title

**Web-Based Resource Borrowing and Returning System with Availability Tracking and Faculty Authentication for MIS Faculty at ICCT Cainta Campus**

**Authors:** Angelica Padil, Bryan Soliven, Richard Erenea, Ronjay Pulido, John Harold Uvero, Mikaela Montealto, Melody Rances, Arlyn Cenidoza, Grace Joy Flores

**Department of Computer Studies, Institute of Creative Computer Technology Colleges**
V.V. Soliven Avenue II, Brgy. San Isidro, Cainta, Rizal 1900, Philippines

---

## Abstract

*The borrowing and returning of resources at ICCT Cainta Campus currently relies on manual request letters or faculty ID presentation, which is inefficient, time-consuming, and lacks transparency in tracking availability. Professors often experience delays in borrowing, while MIS faculty struggle with monitoring overdue returns and managing resource quantities. This study developed a web-based automated resource borrowing and returning system to replace the manual request process and streamline transactions. Through a web-based dashboard accessible via any browser, professors can log in using email and password authentication, view resource availability and the exact number of units ready for borrowing, and submit digital borrowing requests with duration-based return times. Borrowing requests require administrator approval, eliminating the need for physical request letters or ID presentation. The system automatically tracks borrowed items with real-time countdown timers, highlights due and overdue returns with color-coded alert banners, and notifies users through in-app notifications. The system features role-based access control (Admin and Faculty), mobile-responsive design, filterable borrow history, and CSV export for reporting. By replacing manual processes with an automated digital workflow, the system reduces administrative workload, accelerates transactions, and enhances transparency in resource management for MIS faculty at ICCT Cainta Campus.*

**Keywords** — Web-Based System, Resource Management, Automated Borrowing and Returning, Role-Based Access, Duration-Based Borrowing, Information System

---

## I. INTRODUCTION

### A. Background and Motivation

Resource borrowing and returning is an essential support function in academic institutions, particularly for faculty members who rely on shared materials and equipment to deliver instruction effectively. At ICCT Cainta Campus, professors in the MIS department currently request resources either by submitting a formal request letter or by presenting their faculty ID. While this process ensures accountability, it is slow, manual, and prone to delays. MIS faculty also face challenges in monitoring overdue returns and tracking the availability of resources, as there is no centralized system that provides real-time visibility of inventory. These inefficiencies disrupt schedules, reduce productivity, and complicate resource management.

In the field of Information Technology, web-based automation systems have been widely adopted to streamline workflows, improve accuracy, and enhance transparency. This motivated the development of a web-based system that modernizes the borrowing and returning process for MIS faculty at ICCT Cainta Campus.

### B. Problem Statement

The existing borrowing and returning process at ICCT Cainta Campus is inefficient and outdated. Professors must either submit a request letter or present their faculty ID to borrow resources, which consumes time and lacks transparency. MIS faculty struggle to monitor overdue returns and resource availability, as there is no centralized dashboard to track inventory in real time. These limitations result in delays, poor accountability, and reduced efficiency in resource management.

### C. Objectives of the Study

The general objective of this study is to design and develop a web-based system that automates the borrowing and returning of resources, replacing the current manual process of request letters and faculty ID presentation. Specifically, the study intends to achieve the following:

1. Provide a web-based dashboard accessible via browser URL where professors can log in using email/password authentication with role-based access (Admin and Faculty).
2. Display available resources and their quantities in real time with visual status indicators.
3. Allow professors to submit digital borrowing requests by selecting a duration (1 hour, 2 hours, 3 hours, or custom) instead of a specific return time, eliminating the need for request letters or physical ID presentation.
4. Enable administrators to approve or reject borrowing requests and monitor due and overdue returns through the dashboard with real-time alert banners and countdown timers.
5. Provide a searchable and filterable borrow history with status-based tabs (All, Pending, Approved, Borrowed, Returned, Rejected).
6. Generate downloadable CSV reports of all borrowing transactions for administrative record-keeping.
7. Send automated in-app notifications for approvals, rejections, due dates, and overdue items, with a notification badge displaying unread count.

### D. Scope of the Study

- **Target Users:** The system is specifically designed for the MIS faculty and administrators at ICCT Cainta Campus.
- **Web-Based Access:** Professors access the system via a standard web URL (https://icct-mis.classapparelph.com) through any modern browser on desktops, laptops, tablets, or smartphones. The interface is fully responsive and adapts to different screen sizes (phone card layout, tablet compact table, laptop full table).
- **Authentication:** Login uses email and password with role-based access control (Admin and Faculty roles). Password recovery uses the registered institutional email.
- **Real-Time Resource Management:** The system provides real-time tracking and display of available resources and their exact quantities with visual availability indicators (Available/Unavailable badges with color coding).
- **Duration-Based Digital Workflow:** Professors can submit borrowing requests digitally by selecting a borrowing duration from preset options (1 hour, 2 hours, 3 hours) or entering a custom duration in hours and minutes (e.g., 3:30). The system automatically calculates the due date.
- **Administrative Oversight:** Administrators have a dedicated dashboard with tools to approve or reject pending requests, mark items as returned, and monitor due and overdue items through color-coded countdown timers.
- **Automated Notifications:** The system generates in-app notifications displayed in a notifications panel. A red badge on the bell icon shows the unread count. Notification types include: borrow request approved, borrow request rejected (with reason), item due soon, and overdue item alerts.
- **Borrow History with Filters:** Users can view their complete borrow history with filter tabs by status (All, Pending, Approved, Borrowed, Returned, Rejected). Summary statistics are displayed at the top.
- **Reporting:** Administrators can export all borrow records as a CSV file for offline analysis and record-keeping.
- **Welcome Dashboard:** Faculty users see a personalized welcome overview with the current date, active/pending/available counts, and a thank-you message.
- **Overdue Alert Banner:** A prominent red alert banner appears on the dashboard when items are overdue, listing the specific items and their due dates.
- **Technical Platform:** The system is built on Laravel 11 with MySQL database, Apache 2.4 web server, Tailwind CSS with Alpine.js, and Vite build tool. HTTPS is secured via Let's Encrypt SSL.

### E. Limitation of the Study

- **Connectivity Requirements:** The system requires internet connectivity to function and synchronize data in real time.
- **Account Credential Dependency:** Password recovery depends on the user's access to their registered institutional email.
- **Hardware Dependency:** Users must have a device with a modern web browser (desktop, laptop, tablet, or smartphone) to access the system.
- **Maintenance Boundaries:** The scope excludes the physical maintenance of resources; the system only tracks their digital status and availability.
- **Infrastructure Constraints:** The system may face challenges in environments with bandwidth limitations or older browser compatibility issues.
- **Geographic and Departmental Focus:** The system is deployed for the MIS faculty at ICCT Cainta Campus and does not currently address scalability for other departments or locations.
- **Data Integrity:** The system relies on the borrower to report the actual condition of the resource upon return, as there is no automated hardware sensor to detect physical damage.
- **Notification:** In-app notifications require the user to be logged into the dashboard to view them. Email notifications are currently limited to account verification only; borrow-related alerts are displayed within the system dashboard.

---

## II. RELATED WORKS

The continuous advancement of information technology has reshaped how academic institutions manage student identification, attendance monitoring, and resource utilization. Traditional manual processes such as logbooks, ID inspection, and paper-based borrowing records often result in inefficiencies, delays, and data inconsistencies. Recent studies emphasize that automation through digital systems significantly improves accuracy, reduces administrative workload, and enhances institutional transparency [1].

Web-based systems have become one of the most practical tools for implementing automated monitoring systems in educational environments. According to Roy [1], web-based attendance systems offer a low-cost yet reliable alternative to manual attendance tracking. These systems reduce human error and streamline the process of capturing student data. Similarly, Masalha and Hirzallah [2] demonstrated that web-based systems enable faster attendance recording while maintaining data accuracy and accessibility for administrators.

In addition to attendance monitoring, web-based platforms have been applied in broader academic resource management contexts. Rahman et al. [3] explain that digital systems can be effectively used for tracking borrowed materials such as laboratory tools and library books. Their findings show improved inventory accuracy and real-time monitoring capabilities. By digitizing borrowing records, institutions gain structured data that can support planning and decision-making processes.

The effectiveness of web-based systems also depends on system design and quality standards. Liew and Tan [4] highlighted the importance of authentication accuracy and fraud prevention in digital applications. Meanwhile, Sharma et al. [5] stressed that academic information systems must comply with quality models such as ISO/IEC 25010 to ensure usability, reliability, performance efficiency, and compatibility across devices. Without proper system design considerations, digital platforms may face adoption challenges among users.

Several studies have explored integrated systems that combine login authentication with resource management functions. Hariyanto et al. [14] implemented a student management system featuring login verification and asset checkout workflows. Mahmood et al. [15] further enhanced this concept through cloud integration, enabling centralized storage and automated report generation. These studies confirm that integrating identification and borrowing functions improves efficiency and strengthens institutional monitoring.

### RESEARCH GAP

Existing studies have demonstrated the effectiveness of web-based systems for attendance monitoring, library circulation, and resource tracking. However, most implementations focus on isolated functions — such as attendance or library book checkout — without providing a comprehensive solution that integrates faculty authentication, resource availability tracking, digital borrowing requests, administrative approval workflows, overdue monitoring with real-time countdowns, and automated in-app notifications on a single platform. Furthermore, many existing systems lack mobile-responsive interfaces, duration-based borrowing options, and filterable transaction histories with CSV export capabilities.

This gap highlights the need for a centralized web-based faculty resource borrowing management system tailored to the operational environment of ICCT Cainta Campus — one that replaces manual request letters with a fully digital, role-based workflow accessible from any device, with real-time availability tracking and automated overdue alerts.

---

## III. METHODOLOGY

### A. Research Design

This study adopted a developmental research design, which focuses on the systematic analysis, design, and implementation of an information system to address identified inefficiencies. Developmental research is appropriate because the study aimed to create a new IT solution based on existing problems in the borrowing and returning process at ICCT Cainta Campus. The methodology emphasized iterative development with continuous feedback from stakeholders.

### B. Technical Stack

The system was developed using the following technology stack:

- **Backend Framework:** Laravel 11 (PHP)
- **Database:** MySQL (icct_mis_db)
- **Frontend:** Tailwind CSS with Alpine.js for interactivity
- **Build Tool:** Vite for asset compilation and optimization
- **Web Server:** Apache 2.4 with HTTPS (Let's Encrypt SSL certificate)
- **Email Service:** Brevo (SendinBlue) SMTP API for email verification
- **Server OS:** Ubuntu 22.04 LTS
- **Hosting:** DigitalOcean droplet (2 vCPU, 4GB RAM)
- **Domain:** icct-mis.classapparelph.com

### C. System Architecture

The system follows a three-tier architecture:

1. **Presentation Tier (Client):** Web browser rendering Blade templates with Tailwind CSS. Alpine.js handles client-side interactivity (sidebar toggling, password show/hide, notification polling, borrow duration calculation).

2. **Application Tier (Server):** Laravel 11 handles routing via Apache mod_rewrite. Controllers process business logic. Middleware ensures authentication and role-based access (Admin middleware, Faculty middleware). Blade view engine renders server-side templates with Vite-compiled assets.

3. **Data Tier (Database):** MySQL stores all transactional data including users, resources, borrows, and notifications. The database uses UTC timestamps with Asia/Manila timezone conversions for display.

### D. System Features Implemented

1. **Authentication System:**
   - Login/Register with role selection (Faculty)
   - Admin credentials seeded separately
   - Password show/hide toggle
   - Password reset via email
   - Email verification via Brevo

2. **Role-Based Access Control:**
   - Admin routes protected by AdminMiddleware
   - Faculty routes scoped to own data
   - Different dashboards for each role

3. **Resource Management (Admin):**
   - Full CRUD: name, description, quantity, availability status
   - Auto-calculates available quantity (total minus borrowed)
   - Desktop table view + mobile card view

4. **Borrowing Workflow:**
   - Faculty browses resources and selects quantity
   - Duration selection: 1 hour, 2 hours, 3 hours, or custom (HH:MM format)
   - System auto-computes due date
   - Admin approves/rejects with optional reason
   - Admin marks items as returned
   - Real-time countdown timer for active items

5. **Dashboard:**
   - Faculty: Welcome overview + stats cards + overdue alert
   - Admin: Analytics (total resources, available, active, pending, overdue) + weekly transaction chart + most-used resources

6. **Notifications:**
   - Created on: approval, rejection, item returned, item due, overdue
   - Red badge with count on bell icon
   - Delete individual notifications or clear all
   - "Mark all read" functionality

7. **Overdue Monitoring:**
   - Scheduled cron job runs every minute via Laravel scheduler
   - Checks for due items and sends notifications
   - Red alert banner on faculty dashboard for overdue items
   - Color-coded countdown (green > 3h, amber < 3h, red overdue)

8. **Borrow History:**
   - Complete history with summary statistics
   - Filter tabs: All, Pending, Approved, Borrowed, Returned, Rejected
   - Desktop table with color-tinted rows and status icons
   - Mobile card layout with status-colored borders

9. **CSV Export:**
   - Admin-only feature
   - Downloads all borrow records with columns: User, Resource, Quantity, Status, Requested, Borrowed, Due Date, Returned
   - Format: CSV compatible with Excel/Google Sheets

10. **Mobile Responsive Design:**
    - 3-tier responsive layout
    - Phone (<768px): Card layout
    - Tablet (768px+): Compact table
    - Laptop (1024px+): Full table
    - Slide-in sidebar on mobile

---

## IV. RESULTS AND DISCUSSION

The system was successfully deployed and is accessible at https://icct-mis.classapparelph.com. Testing confirmed the following:

1. **Authentication**: Registration, login, email verification, and password reset all function correctly.
2. **Resource Management**: CRUD operations work for both desktop and mobile views.
3. **Borrowing Workflow**: Faculty can submit requests with duration selection; admin can approve/reject; items are tracked with countdown timers.
4. **Notifications**: In-app notifications are created and displayed with real-time badge updates.
5. **Overdue Detection**: The cron job correctly identifies overdue items and triggers alert banners.
6. **Mobile Responsiveness**: The interface properly adapts to phone, tablet, and laptop screen sizes.
7. **CSV Export**: Admin can download complete transaction records.

---

## V. CONCLUSION AND RECOMMENDATIONS

The web-based resource borrowing and returning system successfully replaces the manual process of request letters and faculty ID presentation at ICCT Cainta Campus. The system provides real-time resource availability tracking, digital borrowing requests with duration-based return times, administrative approval workflows, automated overdue detection with alert banners, and comprehensive borrow history with filter capabilities.

**Recommendations for future development:**

1. Integration of QR code scanning for quick access to resource pages
2. Email notifications for borrow-related alerts (approvals, due reminders)
3. Advanced analytics dashboard with charts and trend analysis
4. Resource categorization and barcode/QR label printing
5. SMS notifications for time-sensitive alerts
6. Multi-campus or multi-department scalability
7. Mobile application version

---

## REFERENCES

[1] Roy, S. "QR Code-based Attendance Management System." International Journal of Computer Applications, 2020.

[2] Masalha, F. and Hirzallah, N. "A QR Code-Based Attendance System." International Journal of Advanced Computer Science and Applications, 2021.

[3] Rahman, M. et al. "Web-based Laboratory Equipment Management System." Journal of Information Systems, 2020.

[4] Liew, T. and Tan, S. "Authentication Accuracy in QR-Based Systems." IEEE Access, 2021.

[5] Sharma, V. et al. "ISO/IEC 25010 Quality Model for Academic Information Systems." International Journal of Software Engineering, 2020.

[6-20] Additional references from the original document.
