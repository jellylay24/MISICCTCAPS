<?php

namespace App\Http\Controllers\Faculty;

use App\Http\Controllers\Controller;
use App\Models\Borrow;
use App\Models\Resource;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BorrowController extends Controller
{
    public function create(Resource $resource)
    {
        return view('faculty.borrows.create', compact('resource'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'resource_id' => 'required|exists:resources,id',
            'quantity' => 'required|integer|min:1',
            'duration' => 'nullable|string',
            'due_at' => 'required|date|after:now',
            'room' => 'nullable|string|max:100',
        ]);

        $resource = Resource::findOrFail($validated['resource_id']);
        $available = $resource->availableQuantity();

        if ($validated['quantity'] > $available) {
            return back()->with('error', 'Not enough available quantity.');
        }

        // Parse the user's selected local time and convert to UTC for storage.
        // <input type="datetime-local"> sends local time (e.g., PHT/UTC+8)
        // WITHOUT timezone info. We explicitly interpret as Asia/Manila
        // then convert to UTC for consistent storage.
        // Strip any timezone suffix that some browsers may attach (Z, +08:00, etc.)
        $rawInput = preg_replace('/[Z](?:.*)?$|[+][0-9]{2}[:]?[0-9]{2}(?:.*)?$/', '', trim($validated['due_at']));
        // Preserve the exact user-selected time by parsing as Asia/Manila
        $localDue = Carbon::parse($rawInput, 'Asia/Manila');
        // Convert to UTC for storage (database runs in UTC)
        $utcDue = $localDue->copy()->setTimezone('UTC');

        Borrow::create([
            'user_id' => auth()->id(),
            'resource_id' => $validated['resource_id'],
            'quantity' => $validated['quantity'],
            'due_at' => $utcDue,
            'room' => $validated['room'] ?? null,
            'status' => 'pending',
        ]);

        return redirect()->route('faculty.history')
            ->with('success', 'Borrow request submitted for approval.');
    }

    public function history()
    {
        $borrows = Borrow::with('resource')
            ->where('user_id', auth()->id())
            ->orderBy('created_at', 'desc')
            ->get();
        return view('faculty.borrows.history', compact('borrows'));
    }

    public function export()
    {
        $borrows = Borrow::with('resource')
            ->where('user_id', auth()->id())
            ->orderBy('created_at', 'desc')
            ->get();

        $filename = 'borrow-history-' . now()->format('Y-m-d') . '.csv';

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function () use ($borrows) {
            $file = fopen('php://output', 'w');

            // CSV header row
            fputcsv($file, [
                'Resource', 'Quantity', 'Status',
                'Requested', 'Borrowed', 'Due Date', 'Returned'
            ]);

            foreach ($borrows as $b) {
                fputcsv($file, [
                    $b->resource->name,
                    $b->quantity,
                    ucfirst($b->status),
                    $b->created_at->setTimezone('Asia/Manila')->format('M d, Y h:i A'),
                    $b->localBorrowedAt()?->format('M d, Y h:i A') ?: 'N/A',
                    $b->localDueAt()?->format('M d, Y h:i A') ?: 'N/A',
                    $b->localReturnedAt()?->format('M d, Y h:i A') ?: 'N/A',
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
